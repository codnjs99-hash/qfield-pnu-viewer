# 아이패드 설치 방법

## A. QField 앱 설치
1. iPad에서 **App Store** 실행
2. `QField` 검색
3. QField 설치 및 실행

QField 설치 후 iOS 파일 앱의 `나의 iPad > QField` 아래에 QField용 저장공간이 만들어집니다.

## B. 이 플러그인 ZIP을 아이패드에 저장
1. ChatGPT에서 `qfield_pnu_viewer-0.1.0.zip`을 아이패드의 **파일** 앱에 저장합니다.
2. 파일 앱에서 ZIP을 한 번 탭하여 압축을 풉니다.
3. `qfield_pnu_viewer-0.1.0` 폴더가 생성됩니다.

## C. App-wide 플러그인으로 수동 설치
QField 공식 구조는 `QField 앱 디렉터리/plugins/<플러그인 폴더>/main.qml` 입니다.

1. 파일 앱 > **나의 iPad > QField** 로 이동합니다.
2. 그 안에 `plugins` 폴더가 없으면 새 폴더를 만들고 이름을 `plugins`로 합니다.
3. 압축을 푼 플러그인 폴더를 `plugins` 안으로 옮깁니다.
4. 최종 구조가 아래처럼 되어 있는지 확인합니다.

```
나의 iPad
└─ QField
   └─ plugins
      └─ qfield_pnu_viewer
         ├─ main.qml
         ├─ metadata.txt
         └─ icon.svg
```

**중요:** 중간에 폴더가 한 겹 더 생겨 `qfield_pnu_viewer/qfield_pnu_viewer/main.qml`처럼 되면 안 됩니다.

압축 해제 폴더 이름이 `qfield_pnu_viewer-0.1.0`이면 `qfield_pnu_viewer`로 이름을 바꾸는 것을 권장합니다.

5. QField를 완전히 종료한 뒤 다시 실행합니다.
6. QField > **Settings(설정) > Plugins** 로 이동합니다.
7. `PNU Land & Building Viewer`를 찾아 스위치를 켭니다.
8. 처음 플러그인 실행 권한 창이 뜨면 허용합니다.

## D. 공식 URL 설치 방식을 사용할 경우
플러그인 ZIP을 GitHub/회사 웹서버/Dropbox의 직접 다운로드 URL 등에 올려둔 경우:

1. QField > Settings > Plugins
2. **Install plugin from URL**
3. ZIP의 직접 다운로드 URL 붙여넣기
4. 설치 후 플러그인 스위치 켜기

QField 공식 문서에서 App-wide 플러그인의 배포 방식으로 안내하는 방법입니다.

## E. API 키 입력
1. QField > Settings > Plugins
2. `PNU Land & Building Viewer`
3. 설정(Configuration) 버튼
4. VWorld API 키 입력
5. 건축HUB API 키 입력
6. 저장

## F. 실제 사용
1. QGIS 프로젝트를 QFieldSync로 패키징하여 아이패드 QField에서 엽니다.
2. 레이어 목록에서 `연속지적도`처럼 PNU가 있는 필지 레이어를 활성 레이어로 선택합니다.
3. PNU 플러그인 아이콘을 누릅니다.
4. 지도에서 원하는 필지를 탭합니다.
5. 조회창에서 `토지이용계획 조회` 또는 `건축물대장 조회`를 누릅니다.
