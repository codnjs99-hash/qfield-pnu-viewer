import QtQuick
import QtQuick.Controls
import QtQuick.Layouts
import QtCore

import org.qfield
import org.qgis
import Theme

Item {
  id: plugin
  objectName: "qfieldPnuViewer"

  property var mainWindow: iface.mainWindow()
  property var mapCanvas: iface.mapCanvas()
  property var dashBoard: iface.findItemByObjectName("dashBoard")
  property bool pickMode: false
  property string currentPnu: ""
  property string currentLayerName: ""
  property string currentFeatureLabel: ""
  property bool loading: false
  property int pendingLandRequests: 0
  property string landParcelText: ""
  property string landZonesText: ""
  property string buildingText: ""

  readonly property var pnuCandidates: [
    "PNU", "pnu", "Pnu", "필지고유번호", "PIN", "pin",
    "PNU19", "PNU_CD", "PNU_CODE"
  ]

  Settings {
    id: settings
    category: "qfield-pnu-viewer"
    property string vworldKey: ""
    property string buildingKey: ""
  }

  Component.onCompleted: {
    iface.addItemToPluginsToolbar(toolButton)
    try {
      pointHandler.registerHandler("qfield_pnu_viewer", function(point, type, interactionType) {
        if (!plugin.pickMode || interactionType !== "clicked") {
          return false
        }
        plugin.handleMapClick(point)
        return true
      })
    } catch (e) {
      mainWindow.displayToast("PNU Viewer: 지도 선택 핸들러를 등록하지 못했습니다.")
      iface.logMessage("qfield-pnu-viewer handler error: " + e)
    }
  }

  Component.onDestruction: {
    try {
      if (pointHandler.unregisterHandler) {
        pointHandler.unregisterHandler("qfield_pnu_viewer")
      }
    } catch (e) {}
  }

  function configure() {
    settingsDialog.open()
  }

  function normalizePnu(value) {
    var s = String(value === undefined || value === null ? "" : value).trim()
    if (s.endsWith(".0")) s = s.slice(0, -2)
    s = s.replace(/[^0-9]/g, "")
    return s.length === 19 ? s : ""
  }

  function getPnu(feature) {
    for (var i = 0; i < pnuCandidates.length; ++i) {
      try {
        var p = normalizePnu(feature.attribute(pnuCandidates[i]))
        if (p) return p
      } catch (e) {}
    }
    return ""
  }

  function getFeatureLabel(feature) {
    var fields = ["JIBUN", "jibun", "지번", "mnnmSlno", "LOT", "lot"]
    for (var i = 0; i < fields.length; ++i) {
      try {
        var v = feature.attribute(fields[i])
        if (v !== undefined && v !== null && String(v).trim() !== "") return String(v)
      } catch (e) {}
    }
    return "선택 필지"
  }

  function startPick() {
    var layer = dashBoard ? dashBoard.activeLayer : null
    if (!layer) {
      mainWindow.displayToast("먼저 연속지적도(필지) 레이어를 활성 레이어로 선택하세요.")
      return
    }
    pickMode = true
    mainWindow.displayToast("조회할 필지를 한 번 탭하세요 · 활성 레이어: " + layer.name)
  }

  function handleMapClick(point) {
    var layer = dashBoard ? dashBoard.activeLayer : null
    if (!layer) {
      pickMode = false
      mainWindow.displayToast("활성 레이어가 없습니다.")
      return
    }

    var tl = mapCanvas.mapSettings.screenToCoordinate(Qt.point(point.x - 7, point.y - 7))
    var br = mapCanvas.mapSettings.screenToCoordinate(Qt.point(point.x + 7, point.y + 7))
    var rect = GeometryUtils.createRectangleFromPoints(tl, br)
    var it = LayerUtils.createFeatureIteratorFromRectangle(layer, rect)
    var found = null
    var pnu = ""

    while (it.hasNext()) {
      var f = it.next()
      var candidate = getPnu(f)
      if (candidate) {
        found = f
        pnu = candidate
        break
      }
    }

    pickMode = false
    if (!found || !pnu) {
      mainWindow.displayToast("탭한 위치에서 19자리 PNU를 찾지 못했습니다. 활성 레이어와 PNU 필드를 확인하세요.")
      return
    }

    currentPnu = pnu
    currentLayerName = layer.name
    currentFeatureLabel = getFeatureLabel(found)
    landParcelText = ""
    landZonesText = ""
    buildingText = ""
    mainWindow.displayToast("PNU 확인: " + currentPnu)
    resultDialog.open()
  }

  function cleanServiceKey(key) {
    var k = String(key || "").trim()
    if (k.indexOf("%") >= 0) {
      try { k = decodeURIComponent(k) } catch (e) {}
    }
    return k
  }

  function httpGetJson(url, ok, fail) {
    var xhr = new XMLHttpRequest()
    xhr.onreadystatechange = function() {
      if (xhr.readyState !== XMLHttpRequest.DONE) return
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          ok(JSON.parse(xhr.responseText))
        } catch (e) {
          fail("응답을 JSON으로 해석하지 못했습니다: " + e)
        }
      } else {
        fail("HTTP " + xhr.status + (xhr.responseText ? " · " + String(xhr.responseText).slice(0, 240) : ""))
      }
    }
    xhr.onerror = function() { fail("네트워크 연결에 실패했습니다.") }
    xhr.open("GET", url)
    xhr.setRequestHeader("Accept", "application/json")
    xhr.send()
  }

  function recursiveFindObjects(node, predicate, out) {
    if (!node) return
    if (Array.isArray(node)) {
      for (var i = 0; i < node.length; ++i) recursiveFindObjects(node[i], predicate, out)
      return
    }
    if (typeof node === "object") {
      try { if (predicate(node)) out.push(node) } catch (e) {}
      for (var k in node) recursiveFindObjects(node[k], predicate, out)
    }
  }

  function firstValue(obj, keys) {
    if (!obj) return ""
    for (var i = 0; i < keys.length; ++i) {
      var v = obj[keys[i]]
      if (v !== undefined && v !== null && String(v).trim() !== "") return String(v).trim()
    }
    return ""
  }

  function formatNumber(value, suffix) {
    var s = String(value || "").replace(/,/g, "").trim()
    if (!s) return "-"
    var n = Number(s)
    if (isNaN(n)) return String(value)
    return n.toLocaleString(Qt.locale("ko_KR"), 'f', Math.abs(n % 1) > 0.00001 ? 2 : 0) + (suffix || "")
  }

  function queryLandUse() {
    if (!currentPnu) return
    if (!settings.vworldKey.trim()) {
      mainWindow.displayToast("설정에서 브이월드 API 키를 입력하세요.")
      settingsDialog.open()
      return
    }
    loading = true
    pendingLandRequests = 2
    landParcelText = "조회 중…"
    landZonesText = "조회 중…"
    var base = "https://api.vworld.kr/ned/data/"
    var key = encodeURIComponent(settings.vworldKey.trim())
    var pnu = encodeURIComponent(currentPnu)

    httpGetJson(base + "ladfrlList?format=json&key=" + key + "&pnu=" + pnu,
      function(data) {
        var rows = []
        recursiveFindObjects(data, function(o) {
          return o.pnu !== undefined && (o.ldCodeNm !== undefined || o.lndcgrCodeNm !== undefined || o.lndpclAr !== undefined)
        }, rows)
        var r = rows.length ? rows[0] : null
        if (r) {
          var address = firstValue(r, ["ldCodeNm", "platPlc"])
          var lot = firstValue(r, ["mnnmSlno", "jibun"])
          var cat = firstValue(r, ["lndcgrCodeNm", "lndcgrCode"])
          var area = firstValue(r, ["lndpclAr", "area"])
          landParcelText = "소재지  " + (address || "-") + (lot ? " " + lot : "") + "\n" +
                           "지목    " + (cat || "-") + "\n" +
                           "면적    " + (area ? formatNumber(area, " ㎡") : "-")
        } else {
          landParcelText = "필지 기본정보를 찾지 못했습니다."
        }
        finishLandRequest()
      },
      function(err) { landParcelText = "기본정보 조회 실패\n" + err; finishLandRequest() }
    )

    httpGetJson(base + "getLandUseAttr?format=json&key=" + key + "&pnu=" + pnu + "&numOfRows=1000&pageNo=1",
      function(data) {
        var rows = []
        recursiveFindObjects(data, function(o) {
          return o.prposAreaDstrcCodeNm !== undefined || o.prposAreaDstrcCode !== undefined
        }, rows)
        var seen = {}
        var lines = []
        for (var i = 0; i < rows.length; ++i) {
          var name = firstValue(rows[i], ["prposAreaDstrcCodeNm", "prposAreaDstrcCode"])
          if (name && !seen[name]) { seen[name] = true; lines.push("• " + name) }
        }
        landZonesText = lines.length ? lines.join("\n") : "지역·지구 지정내역을 찾지 못했습니다."
        finishLandRequest()
      },
      function(err) { landZonesText = "토지이용계획 조회 실패\n" + err; finishLandRequest() }
    )
  }

  function finishLandRequest() {
    pendingLandRequests = Math.max(0, pendingLandRequests - 1)
    if (pendingLandRequests === 0) loading = false
  }

  function pnuBuildingParams(pnu) {
    var s = normalizePnu(pnu)
    if (!s) return null
    var mountain = s.charAt(10)
    return {
      sigunguCd: s.slice(0, 5),
      bjdongCd: s.slice(5, 10),
      platGbCd: mountain === "2" ? "1" : "0",
      bun: s.slice(11, 15),
      ji: s.slice(15, 19)
    }
  }

  function buildBuildingUrl(endpoint, pnu) {
    var p = pnuBuildingParams(pnu)
    if (!p) return ""
    var key = encodeURIComponent(cleanServiceKey(settings.buildingKey))
    return "https://apis.data.go.kr/1613000/BldRgstHubService/" + endpoint +
      "?serviceKey=" + key +
      "&sigunguCd=" + encodeURIComponent(p.sigunguCd) +
      "&bjdongCd=" + encodeURIComponent(p.bjdongCd) +
      "&platGbCd=" + encodeURIComponent(p.platGbCd) +
      "&bun=" + encodeURIComponent(p.bun) +
      "&ji=" + encodeURIComponent(p.ji) +
      "&numOfRows=100&pageNo=1&_type=json"
  }

  function buildingRows(data) {
    var rows = []
    recursiveFindObjects(data, function(o) {
      return o.mgmBldrgstPk !== undefined || o.platPlc !== undefined || o.bldNm !== undefined || o.dongNm !== undefined
    }, rows)
    var unique = []
    var seen = {}
    for (var i = 0; i < rows.length; ++i) {
      var k = firstValue(rows[i], ["mgmBldrgstPk"]) || JSON.stringify(rows[i])
      if (!seen[k]) { seen[k] = true; unique.push(rows[i]) }
    }
    return unique
  }

  function renderBuildingRows(rows, titlePrefix) {
    if (!rows.length) return ""
    var blocks = []
    for (var i = 0; i < rows.length; ++i) {
      var r = rows[i]
      var name = firstValue(r, ["bldNm", "dongNm"]) || ("건축물 " + (i + 1))
      var dong = firstValue(r, ["dongNm"])
      var purpose = firstValue(r, ["mainPurpsCdNm", "etcPurps"])
      var structure = firstValue(r, ["strctCdNm", "etcStrct"])
      var plat = firstValue(r, ["platPlc", "newPlatPlc"])
      var totArea = firstValue(r, ["totArea"])
      var archArea = firstValue(r, ["archArea"])
      var bcRat = firstValue(r, ["bcRat"])
      var vlRat = firstValue(r, ["vlRat"])
      var ground = firstValue(r, ["grndFlrCnt"])
      var underground = firstValue(r, ["ugrndFlrCnt"])
      var useDay = firstValue(r, ["useAprDay"])
      var s = (titlePrefix || "") + name
      if (dong && dong !== name) s += " · " + dong
      s += "\n소재지  " + (plat || "-")
      s += "\n주용도  " + (purpose || "-")
      s += "\n구조    " + (structure || "-")
      s += "\n건축면적  " + (archArea ? formatNumber(archArea, " ㎡") : "-")
      s += "\n연면적    " + (totArea ? formatNumber(totArea, " ㎡") : "-")
      s += "\n건폐율    " + (bcRat ? formatNumber(bcRat, "%") : "-")
      s += "\n용적률    " + (vlRat ? formatNumber(vlRat, "%") : "-")
      s += "\n층수      지상 " + (ground || "-") + " / 지하 " + (underground || "-")
      s += "\n사용승인  " + (useDay || "-")
      blocks.push(s)
    }
    return blocks.join("\n\n────────────────\n\n")
  }

  function queryBuilding() {
    if (!currentPnu) return
    if (!settings.buildingKey.trim()) {
      mainWindow.displayToast("설정에서 건축HUB API 키를 입력하세요.")
      settingsDialog.open()
      return
    }
    loading = true
    buildingText = "조회 중…"
    var url = buildBuildingUrl("getBrTitleInfo", currentPnu)
    httpGetJson(url,
      function(data) {
        var rows = buildingRows(data)
        if (rows.length) {
          buildingText = renderBuildingRows(rows, "")
          loading = false
          return
        }
        // 동별 표제부가 없을 때 총괄표제부를 한 번 더 확인한다.
        httpGetJson(buildBuildingUrl("getBrRecapTitleInfo", currentPnu),
          function(recap) {
            var rr = buildingRows(recap)
            if (rr.length) {
              buildingText = renderBuildingRows(rr, "[총괄표제부] ")
            } else {
              buildingText = "건축물대장 표제부를 찾지 못했습니다.\n\n※ 여러 필지가 하나의 대지로 묶인 부속지번은 대표지번 기준으로 대장이 존재할 수 있습니다. v0.1에서는 대표지번 역추적은 아직 포함하지 않았습니다."
            }
            loading = false
          },
          function(err2) { buildingText = "건축물대장 조회 실패\n" + err2; loading = false }
        )
      },
      function(err) { buildingText = "건축물대장 조회 실패\n" + err; loading = false }
    )
  }

  QfToolButton {
    id: toolButton
    objectName: "qfieldPnuViewerButton"
    bgcolor: plugin.pickMode ? Theme.mainColor : Theme.darkGray
    iconSource: "icon.svg"
    iconColor: "white"
    round: true
    onClicked: plugin.startPick()
  }

  Dialog {
    id: settingsDialog
    parent: mainWindow.contentItem
    visible: false
    modal: true
    font: Theme.defaultFont
    title: "PNU 조회 플러그인 설정"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: mainWindow.width * 0.88
    height: mainWindow.height * 0.66
    standardButtons: Dialog.Ok | Dialog.Cancel

    onOpened: {
      vworldInput.text = settings.vworldKey
      buildingInput.text = settings.buildingKey
    }
    onAccepted: {
      settings.vworldKey = vworldInput.text.trim()
      settings.buildingKey = buildingInput.text.trim()
      mainWindow.displayToast("API 키 설정을 저장했습니다.")
    }

    ColumnLayout {
      width: parent.width
      height: parent.height
      spacing: 10

      Label {
        Layout.fillWidth: true
        text: "브이월드 API 키"
        font.bold: true
      }
      TextField {
        id: vworldInput
        Layout.fillWidth: true
        placeholderText: "VWorld NED API 인증키"
        echoMode: TextInput.Password
      }
      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: "토지이용계획 조회에 사용합니다. 기존 PC 플러그인에서 사용하던 브이월드 키를 입력하세요."
      }

      Item { Layout.preferredHeight: 8 }

      Label {
        Layout.fillWidth: true
        text: "공공데이터포털 건축HUB API 키"
        font.bold: true
      }
      TextField {
        id: buildingInput
        Layout.fillWidth: true
        placeholderText: "건축물대장정보 서비스 일반 인증키"
        echoMode: TextInput.Password
      }
      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: "국토교통부 건축HUB 건축물대장정보 서비스 키를 입력하세요."
      }

      Item { Layout.fillHeight: true }

      Label {
        Layout.fillWidth: true
        wrapMode: Text.WordWrap
        text: "사용법: PNU가 있는 필지 레이어를 활성화 → PNU 아이콘 → 필지 탭 → 조회 버튼 선택"
      }
    }
  }

  Dialog {
    id: resultDialog
    parent: mainWindow.contentItem
    visible: false
    modal: true
    font: Theme.defaultFont
    title: "토지·건축물 조회"
    x: (mainWindow.width - width) / 2
    y: (mainWindow.height - height) / 2
    width: mainWindow.width * 0.92
    height: mainWindow.height * 0.82
    standardButtons: Dialog.Close

    ColumnLayout {
      width: parent.width
      height: parent.height
      spacing: 10

      Rectangle {
        Layout.fillWidth: true
        Layout.preferredHeight: headerColumn.implicitHeight + 20
        radius: 8
        color: Theme.darkGray

        Column {
          id: headerColumn
          anchors.left: parent.left
          anchors.right: parent.right
          anchors.verticalCenter: parent.verticalCenter
          anchors.margins: 10
          spacing: 4

          Label {
            width: parent.width
            text: plugin.currentFeatureLabel || "선택 필지"
            font.bold: true
            color: "white"
            wrapMode: Text.WordWrap
          }
          Label {
            width: parent.width
            text: "PNU  " + plugin.currentPnu
            color: "white"
            wrapMode: Text.WordWrap
          }
          Label {
            width: parent.width
            text: "레이어  " + plugin.currentLayerName
            color: "white"
            wrapMode: Text.WordWrap
          }
        }
      }

      RowLayout {
        Layout.fillWidth: true
        spacing: 8

        QfButton {
          text: "토지이용계획"
          Layout.fillWidth: true
          enabled: !plugin.loading
          onClicked: plugin.queryLandUse()
        }
        QfButton {
          text: "건축물대장"
          Layout.fillWidth: true
          enabled: !plugin.loading
          onClicked: plugin.queryBuilding()
        }
      }

      BusyIndicator {
        running: plugin.loading
        visible: plugin.loading
        Layout.alignment: Qt.AlignHCenter
      }

      ScrollView {
        Layout.fillWidth: true
        Layout.fillHeight: true
        clip: true

        ColumnLayout {
          width: resultDialog.width - 36
          spacing: 10

          Label {
            Layout.fillWidth: true
            text: "토지이용계획"
            font.bold: true
          }
          Label {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            text: plugin.landParcelText || "위의 [토지이용계획] 버튼을 누르세요."
          }
          Label {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            text: plugin.landZonesText
            visible: plugin.landZonesText !== ""
          }

          Rectangle {
            Layout.fillWidth: true
            Layout.preferredHeight: 1
            color: Theme.darkGray
          }

          Label {
            Layout.fillWidth: true
            text: "건축물대장"
            font.bold: true
          }
          Label {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            text: plugin.buildingText || "위의 [건축물대장] 버튼을 누르세요."
          }

          Item { Layout.preferredHeight: 12 }
          Label {
            Layout.fillWidth: true
            wrapMode: Text.WordWrap
            font.pixelSize: 12
            text: "업무 협의용 조회 기능입니다. 최종 판단은 공식 토지이음·세움터·관할 행정기관 자료와 대조하세요."
          }
        }
      }
    }
  }
}
